public class AddingNumbers {
    int a = 500;
    int b = 300;
    int c = a+b;
    int  r = ((a+b)*(a+b));;

    public static void main(String[] args) {
        AddingNumbers a = new AddingNumbers();
        System.out.println(a.c);
        System.out.println(a.r);
        System.out.println(a.getSquare(2));
    }

    public int addRectangle(int a , int b){
        return r;
    }
    public int getSquare(int d ){
     this.a = (d*d*d*d);
     return a;
    }
}
