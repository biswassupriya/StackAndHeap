public class Collar {
}//instance variables and object lives on the heap
//local variables live on the stack
class Dog{
    Collar c; //instance variables
    String name; //instance variables

    public static void main(String[] args) { //main placed on a stack
        Dog d; //local variable d
        d = new Dog();
        d.go(d);

    }
    void go(Dog dog){   //local variable dog
        c = new Collar();
        dog.setName("Alkali");
        System.out.println(dog.name);
    }
    void setName(String dogName){  // local variable dogName
        name = dogName;
        System.out.println(name);
    }
}
