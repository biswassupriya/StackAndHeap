public class HexTest {
    public static void main(String[] args) {
        int x = 0X0001;
        int y = 0x7fffffff;
        int z = 0xDeadCafe;
        long jo = 110599L;
        long so = 0xFFFFl;
        System.out.println("X = " + x + "  "+  "Y = "+ y + "  " + "Z = " + z + " " + "jo = " + jo + "  " + "so = " + so);
    }
}
