public class Octal {
    public static void main(String[] args) {
        int six = 06;
        int seven = 07;
        int eight = 010;
        int nine = 011;
        int ten = 111;
        int eleven = 112;
        System.out.println("octal 112:"+ " " + eleven);
        System.out.println("octal 010:" + " "+ eight);
        System.out.println("octal 111:" + ten);
        System.out.println("octal 011 : "+ " " + nine);
    }
}
